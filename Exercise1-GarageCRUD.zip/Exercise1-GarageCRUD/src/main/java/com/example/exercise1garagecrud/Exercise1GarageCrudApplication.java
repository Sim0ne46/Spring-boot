package com.example.exercise1garagecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercise1GarageCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(Exercise1GarageCrudApplication.class, args);
    }

}
